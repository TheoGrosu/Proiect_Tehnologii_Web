# Food-Waste

## 1
To start the project, you should  have a mysql server activate with a database with name: "foodwaste".

## 2
Both in the backend folder and in the frontend / food-waste folder:  npm i

## 3
For the backend, you can write in the backend folder: node server.js

## 4
From Extensions, you should install: SCSS Formatter
For the frontend, in food-waste folder, write in the console: npm start



To create the tables, go on this website:
http://localhost:8081/reset
to reset all the tables in the database.


